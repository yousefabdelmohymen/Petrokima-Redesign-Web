document.addEventListener("DOMContentLoaded", function() {
    const navbar = document.querySelector('.header .navbar');
    const searchForm = document.querySelector('.header .search-form');
    const menuBtn = document.querySelector('#menu-btn');
    const searchBtn = document.querySelector('#search-btn');
    const loginBtn = document.querySelector('#login-btn');
    const loginForm = document.querySelector('.header .login-form');
    const contactInfo = document.querySelector('.contact-info');
    const infoBtn = document.querySelector('#info-btn');
    const closeContactInfoBtn = document.querySelector('#close-contact-info');

    // Close login form by default
    loginForm.classList.remove('active');

    if (menuBtn) {
        menuBtn.addEventListener('click', function() {
            navbar.classList.toggle('active');
            searchForm.classList.remove('active'); // Close search form if menu is opened
            loginForm.classList.remove('active'); // Close login form if menu is opened
        });
    }

    if (searchBtn) {
        searchBtn.addEventListener('click', function() {
            searchForm.classList.toggle('active');
            navbar.classList.remove('active'); // Close menu if search form is opened
            loginForm.classList.remove('active'); // Close login form if search form is opened
        });
    }

    if (loginBtn) {
        loginBtn.addEventListener('click', function() {
            loginForm.classList.toggle('active'); // Toggle login form on click
            navbar.classList.remove('active'); // Close menu if login form is opened
            searchForm.classList.remove('active'); // Close search form if login form is opened
        });
    }

    // Remove scroll event listener that closes the navbar

    // Toggle contact info section
    if (infoBtn) {
        infoBtn.addEventListener('click', function() {
            contactInfo.classList.toggle('active');
        });
    }

    // Close contact info section
    if (closeContactInfoBtn) {
        closeContactInfoBtn.addEventListener('click', function() {
            contactInfo.classList.remove('active');
        });
    }
});

var swiper = new Swiper(".home-slider", {
    loop: true,
    grabCursor:true,
    navigation: {
      nextEl: ".swiper-button-next",
      prevEl: ".swiper-button-prev",
    },
});
var swiper = new Swiper(".references-slider", {
    loop: true,
    grabCursor:true,
    spaceBetween: 20,
    breakpoints: {
        640: {
          slidesPerView: 1,
          spaceBetween: 20,
        },
        768: {
          slidesPerView: 2,
        },
        991: {
          slidesPerView: 3,
        },
    },
});

lightGallery(document.querySelector('.solutions .box-container'));
lightGallery(document.querySelector('.partners .box-container'));